<?php
/**
 * Plugin Name: KNBSB Hoofdklasse Standen
 * Plugin URI:  https://stats.knbsbstats.nl
 * Description: Toont de actuele standen van de Honkbal Hoofdklasse via scraping van stats.knbsbstats.nl. Gebruik [hoofdklasse_standen] op elke pagina of post.
 * Version:     2.0.0
 * Author:      Jouw Naam
 * License:     GPL2
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'KNBSB_SOURCE_URL',     'https://stats.knbsbstats.nl/en/events/2025-lucky-day-hoofdklasse-honkbal/standings' );
define( 'KNBSB_CACHE_KEY',      'knbsb_standen_v2' );
define( 'KNBSB_CACHE_DURATION', 15 * MINUTE_IN_SECONDS );
define( 'KNBSB_PLUGIN_URL',     plugin_dir_url( __FILE__ ) );

// ── Shortcode ────────────────────────────────────────────────────────────────

add_shortcode( 'hoofdklasse_standen', 'knbsb_shortcode' );

function knbsb_shortcode( $atts ) {
    $atts = shortcode_atts( [ 'fase' => 'regulier' ], $atts );

    $data = knbsb_get_data();

    wp_enqueue_style( 'knbsb', KNBSB_PLUGIN_URL . 'assets/style.css', [], '2.0.0' );

    if ( is_wp_error( $data ) ) {
        return '<p class="knbsb-error">⚠️ ' . esc_html( $data->get_error_message() ) . '</p>';
    }

    return knbsb_render( $data, $atts['fase'] );
}

// ── Data ophalen ─────────────────────────────────────────────────────────────

function knbsb_get_data() {
    $cached = get_transient( KNBSB_CACHE_KEY );
    if ( $cached !== false ) return $cached;

    $resp = wp_remote_get( KNBSB_SOURCE_URL, [
        'timeout'    => 20,
        'user-agent' => 'Mozilla/5.0 (compatible; WordPress/' . get_bloginfo('version') . ')',
        'headers'    => [ 'Accept-Language' => 'nl-NL,nl;q=0.9' ],
    ]);

    if ( is_wp_error( $resp ) ) return $resp;

    $code = wp_remote_retrieve_response_code( $resp );
    if ( $code !== 200 ) return new WP_Error( 'http', "HTTP $code van KNBSB" );

    $data = knbsb_parse( wp_remote_retrieve_body( $resp ) );

    if ( empty( $data ) ) {
        return new WP_Error( 'parse', 'Geen standen gevonden op de KNBSB-pagina.' );
    }

    set_transient( KNBSB_CACHE_KEY, $data, KNBSB_CACHE_DURATION );
    return $data;
}

// ── Parser ───────────────────────────────────────────────────────────────────

function knbsb_parse( string $html ): array {
    libxml_use_internal_errors( true );
    $doc = new DOMDocument();
    $doc->loadHTML( mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' ) );
    libxml_clear_errors();

    $xpath  = new DOMXPath( $doc );
    $result = [];

    /*
     * Structuur op de pagina:
     *   <h3>Reguliere competitie</h3>
     *   <table>...</table>
     *   <h3>Wildcard A</h3>
     *   <table>...</table>
     *   ...
     *
     * Elke tabelrij heeft de vorm:
     *   <td>#</td>  <td><img logo></td>  <td><a>KOD Teamnaam</a></td>  <td>W</td> <td>L</td> <td>T</td> <td>PCT</td> <td>GB</td>
     */

    $headers = $xpath->query( '//h3' );
    foreach ( $headers as $h3 ) {
        $title = trim( $h3->textContent );

        // Vind de eerste <table> die direct na deze h3 komt (als sibling of neef)
        $table = knbsb_next_table( $h3 );
        if ( ! $table ) continue;

        $rows = knbsb_parse_table( $xpath, $table );
        if ( ! empty( $rows ) ) {
            $result[ $title ] = $rows;
        }
    }

    return $result;
}

/**
 * Zoek de eerstvolgende <table> na een gegeven node (siblings en parent-siblings).
 */
function knbsb_next_table( DOMNode $node ): ?DOMElement {
    $current = $node->nextSibling;
    while ( $current ) {
        if ( $current instanceof DOMElement && $current->nodeName === 'table' ) {
            return $current;
        }
        // Ga ook in wrapper-divs kijken (één niveau diep)
        if ( $current instanceof DOMElement ) {
            $tables = $current->getElementsByTagName( 'table' );
            if ( $tables->length > 0 ) return $tables->item(0);
        }
        $current = $current->nextSibling;
    }
    return null;
}

/**
 * Parseer één standentabel naar een array van rijen.
 * Elke rij: [ 'positie', 'team', 'W', 'L', 'T', 'PCT', 'GB' ]
 */
function knbsb_parse_table( DOMXPath $xpath, DOMElement $table ): array {
    $rows   = [];
    $trs    = $xpath->query( './/tbody/tr', $table );

    foreach ( $trs as $tr ) {
        $tds = $xpath->query( './/td', $tr );
        if ( $tds->length < 4 ) continue;

        // Kolom 0 → positie (#)
        $positie = trim( $tds->item(0)->textContent );

        // Kolom 1 → logo (overslaan) of direct teamnaam als er geen logo-kolom is
        // Kolom 2 → teamnaam (link-tekst begint met 3-letter code, bv. "NEP Curaçao Neptunus")
        // We detecteren of kolom 1 een afbeelding bevat
        $logo_kolom = $tds->item(1)->getElementsByTagName('img')->length > 0 ? 1 : 0;
        $naam_kolom = $logo_kolom + 1;

        if ( $tds->length <= $naam_kolom ) continue;

        $naam_raw = trim( $tds->item( $naam_kolom )->textContent );
        // Verwijder de 3-letterige code prefix (bv. "NEP ") en trim
        $naam = preg_replace( '/^[A-Z]{2,4}\s+/', '', $naam_raw );
        $naam = trim( $naam );

        // Daarna komen W, L, T, PCT, GB
        $offset = $naam_kolom + 1;
        $w   = isset( $tds[ $offset ] )     ? trim( $tds->item( $offset )->textContent )     : '-';
        $l   = isset( $tds[ $offset + 1 ] ) ? trim( $tds->item( $offset + 1 )->textContent ) : '-';
        $t   = isset( $tds[ $offset + 2 ] ) ? trim( $tds->item( $offset + 2 )->textContent ) : '-';
        $pct = isset( $tds[ $offset + 3 ] ) ? trim( $tds->item( $offset + 3 )->textContent ) : '-';
        $gb  = isset( $tds[ $offset + 4 ] ) ? trim( $tds->item( $offset + 4 )->textContent ) : '-';

        if ( $naam === '' || $w === '' ) continue;

        $rows[] = compact( 'positie', 'naam', 'w', 'l', 't', 'pct', 'gb' );
    }

    return $rows;
}

// ── Renderer ─────────────────────────────────────────────────────────────────

function knbsb_render( array $data, string $fase ): string {
    $fase_map = [
        'regulier' => 'Reguliere competitie',
        'wildcard' => 'Wildcard',
        'playoffs' => 'Playoffs',
        'bottom4'  => 'Bottom',
        'holland'  => 'Holland Series',
        'totaal'   => null,
    ];
    $filter = $fase_map[ $fase ] ?? $fase_map['regulier'];

    ob_start(); ?>
    <div class="knbsb-widget">
        <div class="knbsb-header">
            <span class="knbsb-icon">⚾</span>
            <div>
                <div class="knbsb-title">Lucky Day Honkbal Hoofdklasse</div>
                <div class="knbsb-subtitle">2025 · Nederland</div>
            </div>
        </div>

        <?php
        $getoond = 0;
        foreach ( $data as $fase_naam => $rijen ) :
            if ( $filter !== null && stripos( $fase_naam, $filter ) === false ) continue;
            if ( empty( $rijen ) ) continue;
            $getoond++;
        ?>
        <div class="knbsb-fase">
            <div class="knbsb-fase-header"><?php echo esc_html( $fase_naam ); ?></div>
            <div class="knbsb-table-wrap">
                <table class="knbsb-table">
                    <thead>
                        <tr>
                            <th class="knbsb-col-pos">#</th>
                            <th class="knbsb-col-team">Team</th>
                            <th class="knbsb-col-num">W</th>
                            <th class="knbsb-col-num">V</th>
                            <th class="knbsb-col-num">G</th>
                            <th class="knbsb-col-pct">PCT</th>
                            <th class="knbsb-col-num">GB</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $rijen as $i => $r ) : ?>
                        <tr class="<?php echo $i % 2 === 0 ? 'even' : 'odd'; ?>">
                            <td class="knbsb-col-pos"><?php echo esc_html( $r['positie'] ); ?></td>
                            <td class="knbsb-col-team"><?php echo esc_html( $r['naam'] ); ?></td>
                            <td class="knbsb-col-num"><?php echo esc_html( $r['w'] ); ?></td>
                            <td class="knbsb-col-num"><?php echo esc_html( $r['l'] ); ?></td>
                            <td class="knbsb-col-num"><?php echo esc_html( $r['t'] ); ?></td>
                            <td class="knbsb-col-pct"><?php echo esc_html( $r['pct'] ); ?></td>
                            <td class="knbsb-col-num"><?php echo esc_html( $r['gb'] ); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if ( $getoond === 0 ) : ?>
            <p class="knbsb-leeg">Geen standen beschikbaar voor deze fase.</p>
        <?php endif; ?>

        <div class="knbsb-footer">
            Bron: <a href="<?php echo esc_url( KNBSB_SOURCE_URL ); ?>" target="_blank" rel="noopener noreferrer">KNBSB Stats</a>
            &nbsp;·&nbsp; Bijgewerkt: <?php echo esc_html( current_time( 'd-m-Y H:i' ) ); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ── Admin pagina ─────────────────────────────────────────────────────────────

add_action( 'admin_menu', function() {
    add_options_page( 'KNBSB Standen', 'KNBSB Standen', 'manage_options', 'knbsb', 'knbsb_admin' );
});

function knbsb_admin() {
    if ( isset( $_POST['knbsb_flush'] ) && check_admin_referer( 'knbsb_flush' ) ) {
        delete_transient( KNBSB_CACHE_KEY );
        echo '<div class="notice notice-success"><p>✅ Cache gewist.</p></div>';
    }
    $cached = get_transient( KNBSB_CACHE_KEY ) !== false;
    ?>
    <div class="wrap">
        <h1>⚾ KNBSB Hoofdklasse Standen</h1>

        <h2>Shortcodes</h2>
        <table class="widefat" style="max-width:640px">
            <thead><tr><th>Shortcode</th><th>Toont</th></tr></thead>
            <tbody>
                <tr><td><code>[hoofdklasse_standen]</code></td><td>Reguliere competitie (standaard)</td></tr>
                <tr><td><code>[hoofdklasse_standen fase="totaal"]</code></td><td>Alle fases</td></tr>
                <tr><td><code>[hoofdklasse_standen fase="wildcard"]</code></td><td>Wildcard rondes</td></tr>
                <tr><td><code>[hoofdklasse_standen fase="playoffs"]</code></td><td>Playoffs</td></tr>
                <tr><td><code>[hoofdklasse_standen fase="bottom4"]</code></td><td>Bottom 4</td></tr>
                <tr><td><code>[hoofdklasse_standen fase="holland"]</code></td><td>Holland Series</td></tr>
            </tbody>
        </table>

        <h2 style="margin-top:2rem">Cache beheer</h2>
        <p>Standen worden <strong>15 minuten</strong> gecachet. Status: <strong><?php echo $cached ? '✅ Actief' : '❌ Leeg'; ?></strong></p>
        <form method="post">
            <?php wp_nonce_field( 'knbsb_flush' ); ?>
            <input type="submit" name="knbsb_flush" class="button" value="Cache wissen">
        </form>

        <h2 style="margin-top:2rem">Bron URL</h2>
        <p><a href="<?php echo esc_url( KNBSB_SOURCE_URL ); ?>" target="_blank"><?php echo esc_html( KNBSB_SOURCE_URL ); ?></a></p>
    </div>
    <?php
}

register_activation_hook( __FILE__, fn() => delete_transient( KNBSB_CACHE_KEY ) );
register_deactivation_hook( __FILE__, fn() => delete_transient( KNBSB_CACHE_KEY ) );
